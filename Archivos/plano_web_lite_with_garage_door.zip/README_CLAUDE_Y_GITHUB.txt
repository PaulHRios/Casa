PLANO EXPORT BUNDLE
===================

Archivo fuente: plano(1).skp
Tamaño fuente: 4.888 MB

RECOMENDADO PARA GITHUB PAGES
-----------------------------
Usa:
- github_pages_web/index.html
- github_pages_web/assets/plano_light.glb

El GLB es el formato más práctico para web: una sola pieza, más ligero que OBJ y lo carga Three.js directo. Porque aparentemente OBJ decidió que separar geometría, materiales y texturas era una idea razonable.

PARA CLAUDE
-----------
Sube este ZIP completo o, si quieres menos peso, sube solo:
- github_pages_web/assets/plano_light.glb
- github_pages_web/index.html
- manifest.json

PARA SOFTWARE 3D / FALLBACK
---------------------------
- obj_export/plano_meters.obj       -> recomendado; escala en metros
- obj_export/plano_raw_inches.obj   -> unidades internas de SketchUp en pulgadas
- obj_export/plano.mtl              -> materiales
- obj_export/textures/              -> texturas extraídas

DATOS EXTRAÍDOS
---------------
- Vértices: 2611
- Triángulos: 5019
- Líneas: 0
- Definiciones internas: 5
- Materiales: 12

LIMITACIONES
------------
- No pude reconstruir UVs exactos de SketchUp. Las texturas van incluidas, pero su colocación no será fiel en el OBJ.
- El GLB ligero usa colores/materiales simples, no texturas mapeadas. Es mejor para GitHub Pages y carga rápida.
- La geometría fue reconstruida desde model.dat, no exportada con el exportador oficial de SketchUp.

PUBLICAR EN GITHUB PAGES
------------------------
1. Sube la carpeta github_pages_web a tu repo.
2. Activa GitHub Pages desde Settings > Pages.
3. Si quieres que abra directo, mueve el contenido de github_pages_web a la raíz del repo.
4. El archivo index.html ya carga assets/plano_light.glb.


GARAGE DOOR VERIFICATION
------------------------
- Component: OTOPARK+KEPENK
- Status: INCLUDED
- OBJ group: plano_RootModel_OTOPARK_KEPENK_Group_16
- Triangles in garage-door group: 126

This was explicitly checked because the previous export missed it.
